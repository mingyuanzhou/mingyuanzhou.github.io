function [beta,r,ave,outPara,outBeta] = LGNB_Regression(X,y,BiasTerm,PolyaGammaTruncation,Burnin,Collections,IsMexOK)
%%
% Matlba code for the paper:
% M. Zhou, L. Li, D. Dunson and L. Carin, "Lognormal and
% Gamma Mixed Negative Binomial Regression," ICML, 2012
% First Version: Jan, 2012
% This Version: 02/16/2013 (The updated version provides a much more 
% efficient way to sample the negative binomial dispersion parameter $r$)
%
% Coded by Mingyuan Zhou, mingyuan.zhou@duke.edu,
% http://people.ee.duke.edu/~mz1/
%%
% Hierarchical model:
% y_i ~ NegBino(r,p_i),     p_i ~ logitNormal(X\beta, \phi^{-1})
% r ~ Gamma(a_0, 1/h),      h ~ Gamma(b_0, 1/g_0);
% \beta ~ N(0, diag(\alpha_1,...\alpha_P)^{-1}), 
% \alpha_p ~ Gamma(c_0,1/d_0)
% \phi ~ Gamma(e_0,1/f_0)
%%
%Input:
% X: each row of X is a sample covariate vector
% y: a count vector
% BiasTerm: additional predefined sample/group dependent bias
% PolyaGammaTruncation
% Burnin, number of burn-in iterations
% Collections, number of collected samples
% IsMexOK, if you can mex the provided c file, set "IsMexOK = true" for
% faster speed.
%Output:
% beta: regression coefficients
% r: dispersion parameter
% ave: collected samples for dispersion parameter, and noise precision,
% intercept, regression coefficients, and overdispersion level.
% outPara: collected samples
% outBeta: collected samples
%%
% If finding this code helpful, please cite:
% 
% [1] M. Zhou, L. Li, D. Dunson and L. Carin, "Lognormal and
%     Gamma Mixed Negative Binomial Regression," in ICML 2012.
%
% and either one of the following two papers:
%
% [2] M. Zhou and L. Carin, "Augment-and-Conquer Negative Binomial
%     Processes," in NIPS 2012.
%
% [3] M. Zhou and L. Carin, "Negative Binomial Process Count
%     and Mixture Modeling,"  arXiv:1209.3442, Sept. 2012.
%
%   Copyright (C) 2013, Mingyuan Zhou.
%
%   This program is free software; you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation; either version 3, or (at your option)
%   any later version.
% 
%   This program is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
% *************************************************************************
% *************************************************************************
%%

if ~exist('BiasTerm','var')
    BiasTerm = 0;
end
if ~exist('Burnin','var')
    Burnin = 1000;
end
if ~exist('Collections','var')
    Collections = 1000;
end
if ~exist('PolyaGammaTruncation','var')
    PolyaGammaTruncation = 2000;
end
if ~exist('IsMexOK', 'var')
    IsMexOK = false;
end

y = y(:);
T = length(y);
XTX = X'*X;
beta = zeros(size(X,2),1);

outPara= zeros(4,Burnin+Collections);
outBeta= zeros(length(beta),Burnin+Collections);

phi = 1;
alpha = ones(length(beta),1);
r = 100;
Psi = randn(T,1);

ave.r = zeros(1,Collections);
ave.phi = zeros(1,Collections);
ave.beta = zeros(size(X,2),Collections);
ave.Intercept = zeros(1,Collections);
ave.ODL = zeros(1,Collections);

for iter=1:Burnin+Collections
    %Sample omega
    omega = PolyaGamRnd(y+r,Psi,PolyaGammaTruncation);
    
    %Sample Psi
    PsiSig = 1./(phi + omega);
    PsiMu = PsiSig.*((y-r)/2+phi*(X*beta+BiasTerm));
    Psi = PsiMu + randn(T,1).*sqrt(PsiSig);
    
    %Sample beta
    temp = chol(phi*XTX + diag(alpha))\eye(length(beta));
    beta = temp*(randn(length(beta),1) + temp'*phi*(X'*(Psi-BiasTerm)));
    
    %Sample phi=1/simga^2
    phi  = gamrnd(1e-2 + T/2, 1./(1e-2+ sum((Psi - X*beta-BiasTerm).^2)/2));
    
    %Sample alpha
    alpha = gamrnd(1e-2 + 1/2, 1./(1e-2 + beta.^2/2));
    
    %Sample h
    h = gamrnd(1e-2 + 1*1e-2, 1/(1e-2 + r));
    
    %Sample r (Using the data augmentation method described in [2] and [3]
    % [2] M. Zhou and L. Carin, "Augment-and-Conquer Negative Binomial
    %     Processes," in NIPS 2012.    %
    % [3] M. Zhou and L. Carin, "Negative Binomial Process Count
    %     and Mixture Modeling,"  arXiv:1209.3442, Sept. 2012.
    Lsum = CRT_sum(y,r, IsMexOK);    
    r= gamrnd(1e-2 + Lsum, 1./(sum(log(1+exp(Psi)))+ h));     
    
    %p = 1./(1+exp(-Psi));
    %The intercept term is equal to beta(1)+ 1/phi/2+log(r)
    %The Overdispersion level is equal to exp(1/phi)*(1+1/r)-1    
    outPara(:,iter)=[r;phi;beta(1)+ 1/phi/2+log(r);exp(1/phi)*(1+1/r)-1];
    outBeta(:,iter)=beta;    
    if mod(iter,100)==0
        subplot(4,1,1);plot(max(1,iter-2000):iter,outPara(3,max(1,iter-2000):iter));xlim([iter-2000,iter]); title('Intercept, \beta(0) + \sigma^2/2 + ln r')
        subplot(4,1,2);plot(max(1,iter-2000):iter,outBeta(2,max(1,iter-2000):iter));xlim([iter-2000,iter]); title('\beta(1)')
        subplot(4,1,3);plot(max(1,iter-2000):iter,outBeta(3,max(1,iter-2000):iter));xlim([iter-2000,iter]); title('\beta(2)')
        subplot(4,1,4);plot(max(1,iter-2000):iter,outPara(4,max(1,iter-2000):iter));xlim([iter-2000,iter]); title('ODL, Overdispersion Level')
        drawnow
    end
    if iter>Burnin
        ave.r(iter-Burnin) = r;
        ave.phi(iter-Burnin) = phi;
        ave.Intercept(iter-Burnin) = beta(1)+ 1/phi/2+log(r);
        ave.beta(:,(iter-Burnin)) = beta;      
        ave.ODL(iter-Burnin) = exp(1/phi)*(1+1/r)-1;        
    end
end