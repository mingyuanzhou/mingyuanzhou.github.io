% Matlba code for the paper:
% M. Zhou, L. Li, D. Dunson and L. Carin, "Lognormal and
% Gamma Mixed Negative Binomial Regression," ICML, 2012
% Coded by Mingyuan Zhou, mingyuan.zhou@duke.edu,
% http://people.ee.duke.edu/~mz1/

dataset = 'NASCAR';
%dataset = 'MotorIns';

if strcmp(dataset,'NASCAR')
    fid = fopen('race7579.dat.txt');
    %The NASCAR dataset consists of 151 NASCAR races during the
    %1975-1979 Seasons. The response variable is the number
    %of lead changes in a race, and the covariates of a
    %race include the number of laps, number of drivers and
    %length of the track (in miles).
    %data source:
    %'http://www.stat.ufl.edu/~winner/data/race7579.dat'
    C = textscan(fid, '%d %d %d %d %f %d %d %d %d %s %s %s %*[^\n]');
    fclose(fid);
    X = [double(C{6}),double(C{4}),double(C{5})];
    %X=[double(C{6}),double(C{5})/10,double(C{4})/10];
    X = double([ones(size(X,1),1),X]);
    y = double(C{9});
    BiasTerm=0;
    %Results of negative binomial regression with Maximum likelihood
    %estimation:
    Beta0 = [-0.5038,0.0017,0.0597,0.5153]' 
    ODL0=1/5.2484        
end

if strcmp(dataset, 'MotorIns')    
    fid = fopen('T68.1.txt');
    %The MotorIns dataset consists of Swedish
    %third-party motor insurance claims in 1977. Included
    %in the data are the total number of claims for automo-
    %biles insured in each of the 315 risk groups, defined by
    %a combination of DISTANCE, BONUS, and MAKE
    %factor levels. The number of insured automobile-years
    %for each group is also given. As in Dean et al. (1989),
    %a 19 dimensional covariate vector is constructed for
    %each group to represent levels of the factors.    
    C = textscan(fid, '%d %d %d %d %f %d %f %f %f %*[^\n]');
    fclose(fid);
    Temp = (double(C{4}));
    %X = [fix(Temp/1000),fix(mod(Temp,100)/10),mod(Temp,10)];
    x1 = fix(Temp/1000);
    dex1 = find(x1>=2);
    zone = fix(mod(Temp,1000)/100);
    x2 = fix(mod(Temp,100)/10);
    dex2 = find(x2>=2);
    x3 = mod(Temp,10);
    dex3= find(x3>=2);
    xx = [x1,x2,x3];
    [B,I,J] = unique(xx,'rows');
    T = double(C{5});
    Bias = zeros(size(B,1),1);
    for i=1:length(B)
        Bias(i) = sum(T(J==i));
    end
    BiasTerm = log(T);
    
    X = [sparse(dex1,x1(dex1)-1,1,length(x1),4), sparse(dex2,x2(dex2)-1,1,length(x2),6), sparse(dex3,x3(dex3)-1,1,length(x3),8)];
    X = double([ones(size(X,1),1),X]);
    y = double(C{6});
    
    X = X(1:end,:);
    y = y(1:end);
    
    TestX = X(zone~=1,:);
    Testy = y(zone~=1);
    Testbb = BiasTerm(zone~=1);
    
    X = X(zone==1,:);
    y = y(zone==1);
    BiasTerm=BiasTerm(zone==1);
    
    %Results of Dean et al. (1989)
    Beta0 = [-1.716 0.170 0.226 0.280 0.528 -0.551 -0.698 -0.910 -1.000 -1.049 -1.483 0.159 -0.149 -0.513 0.110 -0.416 -0.155 0.100 -0.029]'
    ODL0 = 0.0115     
end


PolyaGammaTruncation = 500;  %For higer accuracy but lower speed, set PolyaGammaTruncation to be a larger number. 
Burnin = 2000;
Collections = 4000;

%Parameter Settings used in our paper:
%PolyaGammaTruncation = 2000; Burnin = 10000; Collections = 10000;

IsMexOK =  false;

[beta,r,ave,outPara,outBeta] = LGNB_Regression(X,y,BiasTerm,PolyaGammaTruncation,Burnin,Collections,IsMexOK);
%BetaMean = mean(ave.Intercept)
Gap = 5;
Beta = mean(ave.beta(:,Gap:Gap:end),2);
Beta(1) = mean(ave.Intercept(Gap:Gap:end));
Beta
ODL = mean(ave.ODL(Gap:Gap:end))

MU = exp(X*Beta+BiasTerm);
Ei = (y-MU)./(sqrt(MU.*(1+ODL.*MU)));
PearsonResiduals = sum(Ei.^2)

figure;hist(ave.ODL(Gap:Gap:end));title('histogram of \kappa=e^{\sigma^2}(1+1/r)-1')

figure;plot(y,'r');hold on; plot(exp(X*Beta+BiasTerm)); 

figure;
subplot(4,1,1);plot(ave.Intercept); title('Intercept')
subplot(4,1,2);plot(ave.ODL); title('ODL \kappa=e^{\sigma^2}(1+1/r)-1')
subplot(4,1,3);plot(ave.beta(2,:)); title('the first regression coefficient')
subplot(4,1,4);plot(ave.beta(3,:));title('the second regression coefficient')
