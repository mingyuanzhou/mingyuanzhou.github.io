function [ZSDS,WSZS] = Multrnd_Matrix(Xtrain,Theta,PhiTranspose,K,P,N,CountBound)
if nargin<4
    [K,N]=size(Theta);
    P = size(Xtrain,1);
    CountBound=200;
end
    
ZSDS = zeros(K,N);
%WSZS = zeros(P,K);
ZSWS = zeros(K,P);
for i=1:N    
    Xi= Xtrain(:,i);    
    [wi,di,si]=find(Xi);
    x_pik = zeros(K,length(wi));
    count=0;
    ii=zeros(sum(si),1);    
    temp = bsxfun(@times,Theta(:,i),PhiTranspose(:,wi));    
    for ij=1:length(wi)
        if si(ij)<=CountBound
            ii(count+1:count+si(ij))=ij;
            count=count+si(ij);
        else
            x_pik(:,ij) = x_pik(:,ij) + multrnd_histc(si(ij),temp(:,ij));
        end
    end
    x_pik = x_pik+full(sparse(multrnd_unnormalized(temp,ii(1:count)),ii(1:count),1,K,length(wi)));
    ZSDS(:,i) = sum(x_pik,2);    
    ZSWS(:,wi) = ZSWS(:,wi) + x_pik;
end
WSZS = ZSWS';
