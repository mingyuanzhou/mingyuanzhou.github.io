function [ave,Phi,Theta,r_k,p_k,r_i,p_i]=NBP_PFA_mex_v1(percentage,model,eta,K,state,dataset,burnin,collection,CollectionStep)        
% Matlba code for the following papers: 

% M. Zhou and L. Carin, "Negative Binomial Process Count and Mixture Modeling," 
% to appear in IEEE Trans. Pattern Analysis and Machine Intelligence (Special 
% Issue on Bayesian Nonparametrics), Oct. 2013.
% Results in this paper were produced by NBP_PFA_v1.m
% For much faster speed, please use NBP_PFA_mex_v1.m

% M. Zhou and L. Carin, "Augment-and-Conquer Negative Binomial Processes," NIPS 2012.

% M. Zhou, L. Hannah, D. Dunson and L. Carin, "Beta-Negative Binomial Process 
% and Poisson Factor Analysis," AISTATS2012. 
% To reproduce the results in this paper, please set the hyperparameters
% as e_0=f_0=1, and let model = 7 (Using Marked_Beta_NB). 

% First Version: September, 2011
% Second Version: May, 2012
% This Version: August, 2012
%
% Coded by Mingyuan Zhou, mingyuan.zhou@mccombs.utexas.edu,
% http://mingyuanzhou.github.io/
% Copyright (C) 2012, Mingyuan Zhou.
%
% Free of charge for research and education purposes. 
% A license must be obtained from the author to use it
% for commercial purposes.
% 
% *************************************************************************
% *************************************************************************
%%%%%%%%%%%%%%%%%%% Demo %%%%%%%%%%%%%%%%%%%%%%%%
% clear all
% K = 400;     %400, 300, 200, 100, 50, 25, 10, 5
% model = 5;  %1,2,...., 14
% state = 0;   %0,1,2,3,4
% percentage = 0.6; %0.8, 0.6, 0.4, 0.2
% eta = 0.05; %0.01, 0.05, 0.1, 0.25, 0.5, 1
% dataset =1; %1, 2
% burnin = 1000; 
% collection = 1500; 
% CollectionStep = 5;
% *************************************************************************
% *************************************************************************


IsPlot = true;
options = {
    'LDA',
    'NB_LDA',
    'NB_HDP',
    'NB_FTM',
    'Gamma_NB',
    'Beta_NB',
    'Marked_Beta_NB',
    'Marked_Gamma_NB',
    'CRF_HDP_Weak_Limit',
    'Zero_Inflated_NB',
    'CRF_HDP_Weak_Limit_Correct',
    'NB',
    'Beta_Geometric',
    'LDA_optimial_alpha'
};

option = options{model};
if dataset ==1
    disp('psychreview')
    load 'bagofwords_psychreview';
    load 'words_psychreview';
    %This dataset is available at
    %http://psiexp.ss.uci.edu/research/programs_data/toolbox.htm
    X = sparse(WS,DS,1,max(WS),max(DS));
    dex = (sum(X>0,2)<5);
    X = X(~dex,:);
elseif dataset==2
    disp('JACM')
    %The JACM dataset is available at
    %http://www.cs.princeton.edu/~blei/downloads/
    [X,WO] = InitJACM;    
    %load JACM_MZ.mat
    dex=(sum(X>0,2)<=0);
end
WO = WO(~dex);

[P,N] = size(X);

Phi = rand(P,K);
Phi = bsxfun(@rdivide,Phi,sum(Phi,1));
Theta = zeros(K,N)+1/K;
Z = ones(K,N);
Pi = zeros(K,1)+0.01;


rand('state',state)
randn('state',state)

[Xtrain,Xtest]= PartitionX(X,percentage);
Yflagtrain = Xtrain>0;
Yflagtest = Xtest>0;

loglikeTrain = []; loglike=[]; 
ave.loglike=[]; ave.K=[]; ave.PhiTheta = X-X; ave.Count = 0; ave.gamma0=[];
ave.alpha_concentration=[];

%c=1; gamma0=1; r_k= full(sum(Xtrain(:))/N/K/10)*ones(K,1); p_k=ones(K,1)*0.5;
c=1; gamma0=1; r_k= 50/K*ones(K,1); p_k=ones(K,1)*0.5; alpha_concentration=1;
CountBound = 200;
p_i=0.5*ones(1,N);
r_i=r_k(1)*ones(1,N);



disp(option)
disp(['state=',num2str(state)])
disp(['eta=',num2str(eta)])
disp(['Kmax=',num2str(K)])
disp(['Percentage=',num2str(percentage)])

XtrainSparse= sparse(Xtrain);

for iter=1:burnin + collection    

  %  [ZSDS,WSZS] = Multrnd_Matrix(Xtrain,Theta,Phi',K,P,N,CountBound);
    
    %[ZSDS,WSZS] = Multrnd_Matrix_mex(XtrainSparse,Phi,Theta,rand(sum(Xtrain(:)),1));
    [ZSDS,WSZS] = Multrnd_Matrix_mex_fast(XtrainSparse,Phi,Theta);
    %[ZSDS,WSZS] = Multrnd_Matrix_mex(XtrainSparse,Phi,Theta);
    
    
    [kk,jj,ss]=find(ZSDS);
    ll = ss-ss;
    
    if iter<=50
        Theta = gamrnd(ZSDS + r_k(:,ones(1,N)), 0.5);
        %Theta = gamrnd(ZSDS + 50/K, 0.5);
        Phi = dirrnd(WSZS + eta);
    else
         %%
        if strcmp(option,'LDA')                    
            Theta = dirrnd(ZSDS + 50/K);
            Phi = dirrnd(WSZS + eta);
        end
        
        if strcmp(option,'LDA_optimial_alpha')                    
            Theta = dirrnd(ZSDS + 2.5/K);
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'NB_LDA')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            p_i = betarnd(a0 + sum(Xtrain,1),b0+ K*r_i);
            logpi = log(max(1-p_i,realmin));
            p_prime_i = -K*logpi./(c- K*logpi);
            L_i = zeros(1,N);
            for i=1:N
                [L_i(i),ll(jj==i)] = CRT(ss(jj==i),r_i(i));
            end
            gamma0=gamrnd(e0+ CRT(L_i,gamma0),1/(f0-sum(log(max(1-p_prime_i,realmin)))));
            r_i = gamrnd(gamma0 + L_i, 1./(-K*logpi+ c));
            Theta = gamrnd(ZSDS + ones(K,1)*r_i, p_i(ones(K,1),:));
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'NB_HDP') || strcmp(option,'Gamma_NB')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            if strcmp(option,'NB_HDP')
                p_i = 0.5*ones(1,N);
            else
                p_i = betarnd(a0 + sum(Xtrain,1),b0+sum(r_k));
            end
            sumlogpi = sum(log(max(1-p_i,realmin)));
            p_prime = -sumlogpi./(c-sumlogpi);
            L_k = zeros(K,1);
            for k=1:K
            %    [L_k(k),ll(kk==k)] = CRT(ss(kk==k),r_k(k));
                %L_k(k) = CRT_sum(ss(kk==k),r_k(k));                 
                %nk = (ZSDS(k,:)); L_k(k) = CRT_sum_mex(nk,r_k(k),rand(sum(nk),1),max(nk));
                L_k(k) = CRT_sum_mex(ZSDS(k,:),r_k(k));
                %nk = (ZSDS(k,:)); L_k(k) = CRT_sum_mex(nk,r_k(k),rand(sum(nk),1));                
            end            
            %gamma0 = gamrnd(e0 + CRT(L_k,gamma0/K),1/(f0 - log(max(1-p_prime,realmin))));
            gamma0 = gamrnd(e0 + CRT_sum_mex(L_k,gamma0/K),1/(f0 - log(max(1-p_prime,realmin))));
            r_k = gamrnd(gamma0/K + L_k, 1./(-sumlogpi+ c));
            Theta = gamrnd(ZSDS + r_k(:,ones(1,N)), p_i(ones(K,1),:));           
            %Theta = bsxfun(@times,randgamma(ZSDS + r_k(:,ones(1,N))), p_i);
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'NB_FTM') ||  strcmp(option,'Zero_Inflated_NB')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            if strcmp(option,'NB_FTM')
                p_i = 0.5*ones(1,N);
            else
                p_i = betarnd(a0 + sum(Xtrain,1),b0+sum(sparse(diag(r_k))*Z,1));
            end            
            dexdex = (ZSDS==0);
            [dex1,dex2]=find(ZSDS==0);
            p1 = Pi(dex1).*((1-p_i(dex2)').^r_k(dex1));
            p0=(1-Pi(dex1));
            Z = ones(K,N);
            Z(dexdex) = (p1./(p1+p0))>rand(size(dex1));
            Pi = betarnd(c/K+sum(Z,2),c-c/K+N-sum(Z,2));
            
            L_k = zeros(K,1);
            for k=1:K
                [L_k(k),ll(kk==k)] = CRT(ss(kk==k),r_k(k));
            end
            sumbpi = sum(bsxfun(@times,Z,log(max(1-p_i,realmin))),2);
            p_prime_k = -sumbpi./(c-sumbpi);            
            gamma0 = gamrnd(e0 + CRT(L_k,gamma0),1/(f0 - sum(log(max(1-p_prime_k,realmin)))) );
            r_k = gamrnd(gamma0 + L_k, 1./(-sumbpi+ c));
            
            Theta = gamrnd(ZSDS + (r_k(:,ones(1,N))).*Z, p_i(ones(K,1),:));
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'Beta_NB')|| strcmp(option,'Beta_Geometric')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            p_k = betarnd(c/K + sum(ZSDS,2),c*(1-1/K)+sum(r_i));
            if strcmp(option,'Beta_NB')
                sumlogpk = sum(log(max(1-p_k,realmin)));
                %p_prime = -sumlogpk./(c-sumlogpk);
                L_i = zeros(1,N);
                for i=1:N
                    %[L_i(i),ll(jj==i)] = Sample_L_NegBin(ss(jj==i),r_i(i),logF);
                    [L_i(i),ll(jj==i)] = CRT(ss(jj==i),r_i(i));
                end
                %gamma0 = gamrnd(e0 + CRT(L_i,gamma0),1/(f0 - N*log(max(1-p_prime,realmin))) );
                %r_i = gamrnd(gamma0 + L_i, 1./(-sumlogpk+ c));
                r_i = gamrnd(e0 + L_i, 1./(-sumlogpk+ f0));
            else
                r_i = ones(1,N);
            end
            Theta = gamrnd(ZSDS + ones(K,1)*r_i, p_k*ones(1,N));
            Phi = dirrnd(WSZS + eta);
        end
        %%        
        if strcmp(option,'Marked_Beta_NB')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            p_k = betarnd(c/K + sum(ZSDS,2),c*(1-1/K)+r_k*N);
            sumlogpk = N*log(max(1-p_k,realmin));
            %p_prime_k = -sumlogpk./(c-sumlogpk);            
            L_k = zeros(K,1);
            for k=1:K
                %[L_k(k),ll(kk==k)] = CRT(ss(kk==k),r_k(k));
                L_k(k) = CRT_sum_mex(ZSDS(k,:),r_k(k));
            end
            %gamma0 = gamrnd(e0 + CRT(L_k,gamma0),1/(f0 - sum(log(max(1-p_prime_k,realmin)))) );            
            %r_k = gamrnd(gamma0 + L_k, 1./(-sumlogpk + c));
            r_k = gamrnd(e0 + L_k, 1./(-sumlogpk + f0));            
            Theta = gamrnd(ZSDS + r_k(:,ones(1,N)), p_k*ones(1,N));
            %Theta = bsxfun(@times,randgamma(ZSDS + r_k(:,ones(1,N))), p_k);
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'Marked_Gamma_NB')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            %gamma0=1;
            p_k = betarnd(a0 + sum(ZSDS,2),b0+r_k*N);
            sumlogpk = N*log(max(1-p_k,realmin));
            p_prime_k = -sumlogpk./(c-sumlogpk);
            
            L_k = zeros(K,1);
            for k=1:K
                [L_k(k),ll(kk==k)] = CRT(ss(kk==k),r_k(k));
            end
            gamma0 = gamrnd(e0 + CRT(L_k,gamma0/K),1/(f0 - sum(log(max(1-p_prime_k,realmin))/K)) );
            r_k = gamrnd(gamma0/K + L_k, 1./(-N*log(max(1-p_k,realmin))+ c));
            
            Theta = gamrnd(ZSDS + r_k(:,ones(1,N)), p_k*ones(1,N));
            Phi = dirrnd(WSZS + eta);
        end
        %%
        if strcmp(option,'CRF_HDP_Weak_Limit')|| strcmp(option,'CRF_HDP_Weak_Limit_Correct')
            a0=1e-2; b0=1e-2; 
            e0=1e-2; f0=1e-2; c=1;            
            L_k = zeros(K,1);
            for k=1:K
                [L_k(k),ll(kk==k)] = CRT(ss(kk==k),r_k(k));
            end            
            
            %gamma0 = gamrnd(e0 + CRT(ll,gamma0/K),1/(f0 - sum(log(max(1-p_prime_i,realmin)))));          
            if strcmp(option,'CRF_HDP_Weak_Limit')            
                K0 = sum(sum(ZSDS,2)>0);            
                w0 = betarnd(gamma0+1, sum(L_k));
                pi0 = (e0+K0-1)/((e0+K0-1)+sum(L_k)*(f0-log(w0)));             
                %gamma0 = pi0*gamrnd(e0+K0,1/(f0-log(w0))) + (1-pi0)*gamrnd(e0+K0-1,1/(f0-log(w0)));
                gamma0 = gamrnd(e0+K0-(rand(1)>pi0),1/(f0-log(w0))); 
            else
                gamma0 = 1;
            end
            r_tilde_k = dirrnd(gamma0/K + L_k);
            %if strcmp(option,'CRF_HDP_Weak_Limit')                
                wj = betarnd(alpha_concentration+1, full(sum(ZSDS,1)));
                sj = sum(rand(1,N)<sum(ZSDS,1)./(sum(ZSDS,1)+alpha_concentration));            
                alpha_concentration = gamrnd(sum(L_k)+a0 - sj,1/(b0-sum(log(wj))));
%             else
%                 alpha_concentration = 1;
%             end                
            r_k = r_tilde_k*alpha_concentration;            
            Theta = dirrnd(ZSDS + r_k(:,ones(1,N)));
            Phi = dirrnd(WSZS + eta);
        end
        %%
         if strcmp(option,'NB')
            a0=1e-2; b0=1e-2; e0=1e-2; f0=1e-2; c=1;
            p = betarnd(a0 + sum(sum(Xtrain)),b0+gamma0);                    
%             L_k = zeros(K,1);
%             for k=1:K
%                 L_k(k) = CRT(sum(ss(kk==k)),gamma0/K);
%             end            
            gamma0 = gamrnd(e0 + CRT(full(sum(ZSDS,2)),gamma0/K),1/(f0 - log(max(1-p,realmin))));
            r_k = gamrnd(gamma0/K + sum(ZSDS,2), p/N);            
            Theta = r_k(:,ones(1,N));
            Phi = dirrnd(WSZS + eta);
        end
       
    end
       
    if iter>burnin && mod(iter,CollectionStep)==0
        X1 = Phi*Theta;        
        ave.PhiTheta = ave.PhiTheta + X1;
        ave.Count = ave.Count+1;
        temp = ave.PhiTheta/ave.Count;
        temp= bsxfun(@rdivide, temp,sum(temp,1));
        ave.loglike(end+1) = sum(Xtest(Yflagtest).*log(temp(Yflagtest)))/sum(Xtest(:));        
        ave.K(end+1) = nnz(sum(ZSDS,2));    
        ave.gamma0(end+1) = gamma0;
        ave.alpha_concentration(end+1) = alpha_concentration;
        X1 = bsxfun(@rdivide, X1,sum(X1,1));
        %loglike(end+1)=sum(X(Yflag).*log(X1(Yflag)));
        %loglike(end)
        %loglike(end+1)=exp(-sum(Xtest(Yflagtest).*log(X1(Yflagtest)))/sum(Xtest(:)));
        loglike(end+1)=sum(Xtest(Yflagtest).*log(X1(Yflagtest)))/sum(Xtest(:));
        loglikeTrain(end+1)=sum(Xtrain(Yflagtrain).*log(X1(Yflagtrain)))/sum(Xtrain(:));
    end
    
    if mod(iter,10)==0
        if iter>burnin
            disp(full([iter/100,loglikeTrain(end),loglike(end),ave.K(end),ave.loglike(end)]));
        else
            disp(full(iter/100));
        end
    end
    
    if IsPlot && mod(iter,10)==0
        [temp, Thetadex] = sort(sum(Theta,2),'descend');
        subplot(2,2,1);plot((r_k(Thetadex)),'.');
        subplot(2,2,2);plot(p_k(Thetadex));
        subplot(2,2,3);plot(r_i);
        subplot(2,2,4);plot(p_i);
        drawnow
    end   
end
LoglikeFinal = ave.loglike(end);
if state == 0    
    save([option,num2str(state),'_',num2str(percentage*100),'_',num2str(dataset),'_K',num2str(K),'_phi',num2str(fix(eta*100))], 'LoglikeFinal', 'ave', 'Theta','Z','Phi','Pi','loglike','loglikeTrain','ZSDS','WO','eta','r_k','p_k','p_i','r_i','X','Xtrain','Xtest'); %,'WS','DS','WordTrainS','DocTrainS');
else    
    save([option,num2str(state),'_',num2str(percentage*100),'_',num2str(dataset),'_K',num2str(K),'_phi',num2str(fix(eta*100))], 'LoglikeFinal');
end 

