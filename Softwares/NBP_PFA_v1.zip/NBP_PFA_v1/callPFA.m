function callPFA(mode1,mode2,mode3,mode4)
%dataset_all = [1,2];
Percentage_all = [0.8,0.6,0.4,0.2];
% options = {
%     'NB_LDA',
%     'NB_HDP',
%     'NB_FTM',
%     'Gamma_NB',
%     'Beta_NB',
%     'Marked_Beta_NB',
%     'Marked_Gamma_NB',
% };
a_phi_all = [0.01, 0.05, 0.1, 0.25, 0.5, 1];        
K_all = [400, 300, 200, 100, 50, 25, 10, 5];

for state = 0:4
    %dataset= dataset_all(mode1)    
    percentage = Percentage_all(mode1);
    eta =   a_phi_all(mode3);
    K = K_all(mode4);
    burnin=1000;
    collection=1500;
    CollectionStep =1;
    model = mode2;
    dataset = 1;
    NBP_PFA_v1(percentage,model,eta,K,state,dataset,burnin,collection,CollectionStep);   
    %NBP_PFA_mex_v1(percentage,model,eta,K,state,dataset,burnin,collection,CollectionStep); 
end