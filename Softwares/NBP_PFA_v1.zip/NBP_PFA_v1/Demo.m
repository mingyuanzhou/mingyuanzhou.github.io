clear all
K = 400;     %400, 300, 200, 100, 50, 25, 10, 5
model = 7;  %1,2,3,4,5,6
state = 0;   %0,1,2,3,4
percentage = 0.6; %0.8, 0.6, 0.4, 0.2
eta = 0.05; %0.01, 0.05, 0.1, 0.25, 0.5, 1
dataset =1; %1, 2
burnin = 1000; 
collection = 1500; 
CollectionStep = 1;
NBP_PFA_mex_v1(percentage,model,eta,K,state,dataset,burnin,collection,CollectionStep); 
%NBP_PFA_v1(percentage,model,eta,K,state,dataset,burnin,collection,CollectionStep); 