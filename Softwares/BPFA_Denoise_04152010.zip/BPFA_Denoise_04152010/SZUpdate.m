function [S,Z] = SZUpdate(S,Z,rowi,idexNew,idexold)
%Initializing new S and Z with neighboring pacthes which have already been
%used for training in previous training rounds
%Version 1: 09/12/2009
%Version 2: 11/02/2009
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu
if ~isempty(idexNew)
    N = size(idexNew,1);
    if rowi~=1
        TempDex = [idexNew(:,1)-1,idexNew(:,2)];
    else
        TempDex = [idexNew(:,1),idexNew(:,2)-1];
    end
    Pos = zeros(N,1);
    for i=1:N
        Pos(i) = find(TempDex(i,1)==idexold(:,1) & TempDex(i,2)==idexold(:,2),1,'last');
    end
    S=[S;S(Pos,:)];
    Z=[Z;Z(Pos,:)];
end
end