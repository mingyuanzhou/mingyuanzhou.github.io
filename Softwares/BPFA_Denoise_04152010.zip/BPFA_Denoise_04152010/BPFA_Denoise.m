
function [ave,Iout,D,S,Z,idex,Pi,NoiseVar,alpha,phi,PSNR,PSNRave] = BPFA_Denoise(IMin, PatchSize, K, DispPSNR, IsSeparateAlpha, InitOption, LearningMode, IterPerRound,ReduceDictSize, IMin0, sigma, IMname)
%------------------------------------------------------------------
% The BPFA grayscale image denoising program for the paper:
% "Non-Parametric Bayesian Dictionary Learning for Sparse Image
% Representations," Neural Information Processing Systems (NIPS), 2009.
% Coded by: Mingyuan Zhou, ECE, Duke University, mz1@ee.duke.edu
% Version 0: 06/14/2009
% Version 1: 09/13/2009
% Version 2: 10/21/2009
% Version 3: 10/28/2009
% Version 4: 11/03/2009
% Updated in 03/30/2010
%
%------------------------------------------------------------------
% Input:
%   IMin: noisy image.
%   PatchSize: patch size, 8 is commonly used.
%   K: predefined dictionary size.
%   DispPSNR: calculate and display the instant PSNR during learning if it
%   is TRUE
%   IsSeparateAlpha: use a separate precision for each factor score vector
%   if it is TRUE.
%   InitOption? 'SVD' or 'Rand';
%   LearningMode: 'online' or 'batch';
%   IterPerRound: maximum iteration in each round.
%   ReduceDictSize: reduce the dictionary size during learning if it is
%   TRUE
%   IMin0: original noise-free image (only used for PSNR calculation and
%   would not affect the denoising results).
%   sigma: noise variance (has no effect on the denoising results).
%   IMname: image name (has no effect on the deoising results).

% Output:
%   ave: denoised image (averaged output)
%   Iout: denoised image (sample output)
%   D: dictionary learned from the noisy image
%   S: basis coefficients
%   Z: binary indicators for basis usage
%   idex: patch index
%   Pi: the probabilities for each dictionary entries to be used
%   NoiseVar: estimated noise variance
%   alpha: precision for S
%   phi: noise precision
%   PSNR: peak signal-to-noise ratio
%   PSNRave: PSNR of ave.Iout
%------------------------------------------------------------------

if nargin < 2
    PatchSize=8;
end
if nargin < 3
    K=256;
end
if nargin < 4
    DispPSNR = true;
end
if nargin < 5
    IsSeparateAlpha = false;
end
if nargin < 6
    InitOption = 'SVD';
end
if nargin < 7
    LearningMode = 'online';
end
if nargin < 8
    IterPerRound = ones(PatchSize,PatchSize);
    IterPerRound(end,end) = 50;
end
if nargin < 9
    ReduceDictSize = false;
end
if nargin < 10
    IMin0=IMin;
end
if nargin < 11
    sigma=[];
end
if nargin < 12
    IMname=[];
end

sizeIMin = size(IMin);
idex=[];
PSNR=[];
NoiseVar=[];
X_k=[];
PSNRave = 0;

% Set Hyperparameters
c0=1e-6;
d0=1e-6;
e0=1e-6;
f0=1e-6;

ave.Iout = zeros(size(IMin));
ave.Count = 0;


if strcmp(LearningMode,'online')==1
    for colj=1:PatchSize
        for rowi=1:PatchSize
            idexold = idex;
            idexNew = idexUpdate(sizeIMin,PatchSize,colj,rowi);
            idex = [idexold;idexNew];
            X_k = Update_Input(X_k,IMin,idexNew,PatchSize);
            [P,N] = size(X_k);
            
            %Sparsity Priors
            if strcmp(InitOption,'SVD')==1
                a0=1;
                b0=N/8;
            else
                a0=1;
                b0=1;
            end
            
            %Initializations for new added patches
            if rowi==1 && colj==1
                %Random initialization
                [D,S,Z,phi,alpha,Pi] = InitMatrix_Denoise(X_k,K,InitOption,IsSeparateAlpha,IMin);  
            else
                %Initialize new added patches with their neighbours
                [S,Z] = SZUpdate(S,Z,rowi,idexNew,idexold);
            end
            idext = N-size(idexNew,1)+1 : N;
            %X_k(:,idext) = X_k(:,idext) - D*S(idext,:)';
            X_k(:,idext) = X_k(:,idext) - D*(S(idext,:).*Z(idext,:))';
            maxIt = IterPerRound(colj,rowi);
            
            for iter=1:maxIt
                tic
                %Sample D, Z, and S
                if size(IMin,3)==1
                    Pi(1) = 1;
                end
                [X_k, D, Z, S] = SampleDZS(X_k, D, Z, S, Pi, alpha, phi, true, true, true);
                %Sample Pi
                Pi = SamplePi(Z,a0,b0);
                %Sample alpha
                alpha = Samplealpha(S,e0,f0,Z,alpha);
                %Sample phi
                phi = Samplephi(X_k,c0,d0);
                ittime=toc;
                
                NoiseVar(end+1) = sqrt(1/phi)*255;
                if ReduceDictSize && colj>2
                    sumZ = sum(Z,1)';
                    if min(sumZ)==0
                        Pidex = sumZ==0;
                        D(:,Pidex)=[];
                        K = size(D,2);
                        S(:,Pidex)=[];
                        Z(:,Pidex)=[];
                        Pi(:,Pidex)=[];
                        alpha(Pidex)=[];
                    end
                end
                
                if DispPSNR==1 || (rowi==PatchSize&&colj==PatchSize)
                    if rowi==PatchSize
                        %Iout    =   DenoiseOutput(D*(S.*Z)',sizeIMin,PatchSize,idex,MuX);
                        Iout    =   DenoiseOutput_LowMemoryReq(D,S,sizeIMin,PatchSize,idex);
                        if colj==PatchSize
                            ave.Count = ave.Count + 1;
                            if ave.Count==1
                                ave.Iout = Iout;
                            else
                                ave.Iout= 0.85*ave.Iout+0.15*Iout;
                            end
                            PSNRave = -10*log10((mean((ave.Iout(:)-IMin0(:)).^2)));
                        end
                        PSNR(end+1) = -10*log10((mean((Iout(:)-IMin0(:)).^2)));
                        if rowi==PatchSize && mod(iter,10)==1
                            disp(['round:',num2str([colj,rowi]),'    iter:', num2str(iter), '    time: ', num2str(ittime), '    ave_Z: ', num2str(full(mean(sum(Z,2)))),'    M:', num2str(nnz(mean(Z,1)>1/1000)),'    PSNR:',num2str(PSNR(end)),'    PSNRave:',num2str(PSNRave),'   NoiseVar:',num2str(NoiseVar(end)) ])
                            %save([IMname,'_Denoising_',num2str(sigma),'_',num2str(colj),'_',num2str(rowi)], 'Iout','D','PSNR','Pi','IMin','IMin0','phi','alpha','NoiseVar','idex','ave');
                        end
                    end
                end
            end
        end
    end
    
else
    
    %batch mode
    [idexi,idexj] = ind2sub(sizeIMin(1:2)-PatchSize+1,1:(sizeIMin(1)-PatchSize+1)*(sizeIMin(2)-PatchSize+1));
    idex = [idexi',idexj'];
    clear idexi idexj
    X_k = im2col(IMin,[PatchSize,PatchSize],'sliding');
    [P,N] = size(X_k);    
    %Sparsity Priors
    if strcmp(InitOption,'SVD')==1
        a0=1;
        b0=N/8;
    else
        a0=1;
        b0=1;
    end
    [D,S,Z,phi,alpha,Pi] = InitMatrix_Denoise(X_k,K,InitOption,IsSeparateAlpha,IMin);    
    Pi = Pi-Pi+0.001;
    X_k = X_k - D*S';
    maxIt = IterPerRound(end,end);
    for iter=1:maxIt
        tic
        if size(IMin,3)==1
            Pi(1) = 1;
        end
        [X_k, D, Z, S] = SampleDZS(X_k, D, Z, S, Pi, alpha, phi, true, true, true);
        Pi = SamplePi(Z,a0,b0);
        alpha = Samplealpha(S,e0,f0,Z,alpha);
        phi = Samplephi(X_k,c0,d0);
        ittime=toc;
        
        NoiseVar(end+1) = sqrt(1/phi)*255;
        if ReduceDictSize && iter>20
            sumZ = sum(Z,1)';
            if min(sumZ)==0
                Pidex = sumZ==0;
                D(:,Pidex)=[];
                K = size(D,2);
                S(:,Pidex)=[];
                Z(:,Pidex)=[];
                Pi(Pidex)=[];
            end
        end        
        
        if iter>20
            %Iout    =   DenoiseOutput(D*(S.*Z)',sizeIMin,PatchSize,idex,MuX);
            Iout    =   DenoiseOutput_LowMemoryReq(D,S,sizeIMin,PatchSize,idex);
            ave.Count = ave.Count + 1;
            if ave.Count==1
                ave.Iout = Iout;
            else
                ave.Iout= 0.85*ave.Iout+0.15*Iout;
            end
            PSNRave = -10*log10((mean((ave.Iout(:)-IMin0(:)).^2)));
            PSNR(end+1) = -10*log10((mean((Iout(:)-IMin0(:)).^2)));
            if mod(iter,10)==1
                disp(['iter:', num2str(iter), '    time: ', num2str(ittime), '    ave_Z: ', num2str(full(mean(sum(Z,2)))),'    M:', num2str(nnz(mean(Z,1)>1/1000)), '    PSNR:',num2str(PSNR(end)),'    PSNRave:',num2str(PSNRave),'   NoiseVar:',num2str(NoiseVar(end)) ])
                %save([IMname,'_Denoising_',num2str(sigma),'_',num2str(iter)], 'Iout', 'D','PSNR','Pi','IMin','IMin0','phi','alpha','NoiseVar','idex','ave');
            end
        end
    end    
end
save( [IMname,'_Denoising_',num2str(sigma)], 'Iout', 'D','S','Z','PSNR','Pi','IMin','IMin0','phi','alpha','NoiseVar','idex','ave');
end