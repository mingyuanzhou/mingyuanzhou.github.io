function [D,S,Z,phi,alpha,Pi] = InitMatrix_Denoise(X_k,K,InitOption,IsSeparateAlpha,IMin)
%Initialization
%Version 1: 09/12/2009
%Version 2: 10/21/2009
%Version 3: 10/26/2009
%Version 4: 10/28/2009
%Updated in 03/30/2010
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu

[P,N]=size(X_k);
if nargin<4
    IsSeparateAlpha = false;
end
phi = 1/((25/255)^2);
if IsSeparateAlpha == false
    alpha = 1;
else
    alpha = ones(1,K);
end

if strcmp(InitOption,'SVD')==1
    [U_1,S_1,V_1] = svd(full(X_k),'econ');
    if P<=K
        D = zeros(P,K);
        D(:,1:P) = U_1*S_1;
        S = zeros(N,K);
        S(:,1:P) = V_1;
    else
        D =  U_1*S_1;
        D = D(1:P,1:K);
        S = V_1;
        S = S(1:N,1:K);
    end
    Z = true(N,K);
    Pi = 0.5*ones(1,K);
else
    D = randn(P,K)/sqrt(P);
    S = randn(N,K);
    Z = logical(sparse(N,K));
    Pi = 0.01*ones(1,K);
    %if size(IMin,3)==1
    D(:,1) = mean(X_k,2)*100;
    S(:,1)=1/100;
    Z(:,1)= true;
    %end    
%     muX = mean(X_k,2);
%     P1 = P/size(IMin,3);
%     for channel = 1:size(IMin,3)
%         D((channel-1)*P1 + (1:P1),channel) = muX((channel-1)*P1 + (1:P1));
%         S(:,channel)=1/100;
%         Z(:,channel)= true;
%     end    
end
S = S.*Z;
end





