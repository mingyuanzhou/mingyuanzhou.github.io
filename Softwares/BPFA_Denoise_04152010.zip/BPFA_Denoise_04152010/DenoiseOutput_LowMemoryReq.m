function  Io = DenoiseOutput_LowMemoryReq(D,S,sizeIMin,PatchSize,idex,Yflag)
%Version 1: 11/02/2009
%Updated in 03/08/2010
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu

if nargin<6
    Yflag = [];
end
    
% S = S';
% Io = zeros(sizeIMin);
% Weight = zeros(sizeIMin);
% for i=1:size(idex,1);
%     Pos1  = idex(i,1)+(0:PatchSize-1);
%     Pos2 = idex(i,2)+(0:PatchSize-1);
%     if nargin<8
%         Io(Pos1,Pos2,:) = Io(Pos1,Pos2,:) + reshape(D*(S(:,i)),PatchSize,PatchSize,[]);    
%         Weight(Pos1,Pos2,:) = Weight(Pos1,Pos2,:) + 1;    
%     else
%         Io(Pos1,Pos2,:) = Io(Pos1,Pos2,:) + reshape(D*(S(:,i)),PatchSize,PatchSize,[])*mean(Yflag(:,i));    
%         Weight(Pos1,Pos2,:)= Weight(Pos1,Pos2,:) + mean(Yflag(:,i));    
%     end
% end
% Io = Io./Weight;
% % %Iout = (max(min(Iout,255),0));

% Io = zeros(sizeIMin);
% Weight = conv2(full(sparse(idex(:,1),idex(:,2),1,sizeIMin(1)-PatchSize+1,sizeIMin(2)-PatchSize+1)),ones(PatchSize,PatchSize),'full');
% for p=1:size(D,1)
%     [posi,posj] = ind2sub([8,8],p);
%     Io = Io + sparse(idex(:,1)+posi-1,idex(:,2)+posj-1,S*D(p,:)',sizeIMin(1),sizeIMin(2));        
% end

channelNum = size(D,1)/PatchSize^2;
Io = zeros(sizeIMin(1),sizeIMin(2),channelNum);
Io = reshape(Io,[],channelNum);
Weight = conv2(full(sparse(idex(:,1),idex(:,2),1,sizeIMin(1)-PatchSize+1,sizeIMin(2)-PatchSize+1)),ones(PatchSize,PatchSize),'full');
for p=1:PatchSize^2;
    for channel=1:channelNum        
        [posi,posj] = ind2sub([PatchSize,PatchSize],p);
        ind = sub2ind(sizeIMin(1:2),idex(:,1)+posi-1,idex(:,2)+posj-1);        
        Io(ind,channel) = Io(ind,channel) + S*D(p+(channel-1)*PatchSize^2,:)';       
    end
end    
Io = reshape(Io,sizeIMin(1),sizeIMin(2),[]);
for channel=1:channelNum   
    Io(:,:,channel) = Io(:,:,channel)./(Weight+realmin);
end