function [Iout,D,S,Z,idex,Pi,NoiseVar,alpha,phi,PSNR] = BPFA_Inpainting(IMin, SampleMatrix, PatchSize, K, DispPSNR, IsSeparateAlpha, InitOption, UpdateOption, LearningMode, IterPerRound, ReduceDictSize,IMin0,sigma,IMname,SparseCalculationT)
%------------------------------------------------------------------
% The BPFA RGB image inpainting program for the following paper:
% "Non-Parametric Bayesian Dictionary Learning for Sparse Image
% Representations," Neural Information Processing Systems (NIPS), 2009.
% Coded by: Mingyuan Zhou, ECE, Duke University, mz1@ee.duke.edu
% Version 0: 06/14/2009
% Version 1: 09/13/2009
% Version 2: 10/26/2009
% Version 3: 10/28/2009
% Version 4: 10/29/2009
% Version 5: 11/02/2009
% Updated in 03/09/2010
%------------------------------------------------------------------
% Input:
%   IMin: corrupted image
%   SampleMatrix: binary matrix indicating which pixel values are observed
%   PatchSize: block size, 8 is commonly used.
%   K: predefined dictionary size.
%   DispPSNR: calculate and display the instant PSNR during learning if it
%   is TRUE
%   IsSeparateAlpha: use a separate precision for each factor score vector
%   if it is TRUE.
%   InitOption: 'SVD' or 'Rand'
%   LearningMode: 'online' or 'batch';
%   IterPerRound: maximum iteration in each round.
%   ReduceDictSize: reduce the dictionary size during learning if it is
%   TRUE.
%   IMin0: original noise-free image (only used for PSNR calculation and
%   would not affect the denoising results).
%   IMname: image name.

% Output:
%   ave: inpainted image (averaged output)
%   Iout: inpainted image (sample output)
%   D: dictionary learned from the corrupted image
%   S: basis coefficients
%   Z: binary indicators
%   idex: patch index
%   Pi: the probabilities for each dictionary entries to be used
%   NoiseVar: estimated noise variance
%   alpha: precision for S
%   phi: noise precision
%   PSNR: peak signal-to-noise ratio
%   PSNRave: PSNR of ave.Iout
%------------------------------------------------------------------

if nargin < 3
    PatchSize=8;
end
if nargin < 4
    K=256;
end
if nargin < 5
    DispPSNR = true;
end
if nargin < 6
    IsSeparateAlpha = false;
end
if nargin < 7
    InitOption = 'Rand';
end
if nargin < 8
    UpdateOption = 'DkSkZk';
end
if nargin < 9
    LearningMode = 'online';
end
if nargin < 10
    IterPerRound = ones(PatchSize,PatchSize);
    IterPerRound(end,end) = 50;
end
if nargin < 11
    ReduceDictSize = false;
end
if nargin < 12
    IMin0=IMin;
end
if nargin < 13
    sigma=[];
end
if nargin < 14
    IMname=[];
end

if nargin < 15
    SparseCalculationT = 0.5;
end

if nnz(SampleMatrix)/numel(SampleMatrix) < SparseCalculationT
    IsSparseCalculation = true;
else
    IsSparseCalculation = false;
end

idex=[];
PSNR=[];
NoiseVar=[];
Yflag=[];
X_k=[];

% Set Hyperparameters
c0=1e-6;
d0=1e-6;
e0=1e-6;
f0=1e-6;
sizeIMin = size(IMin);

dataratio = round(100*nnz(SampleMatrix)/numel(SampleMatrix));

ave.Iout = zeros(size(IMin));
ave.Count = 0;


if strcmp(LearningMode,'online')==1
    for colj=1:PatchSize
        for rowi=1:PatchSize
            idexold = idex;
            idexNew = idexUpdate(sizeIMin,PatchSize,colj,rowi);
            idex = [idexold;idexNew];
            [Yflag,X_k] = Update_Input_MissingData(Yflag,X_k,IMin,SampleMatrix,idexNew,PatchSize,IsSparseCalculation);
            [P,N] = size(X_k);
            
            %Sparsity Priors
            if strcmp(InitOption,'SVD')==1
                a0=1;
                b0=N/8;
            else
                a0=1;
                b0=1;
            end
            
            %Initializations for new added patches
            if rowi==1 && colj==1                
                [D,S,Z,phi,alpha,Pi] = InitMatrix_MissingData(X_k,K,Yflag,InitOption,IsSeparateAlpha,IMin);               
            else               
                [S,Z] = SZUpdate(S,Z,rowi,idexNew,idexold);                
            end
            %S=S.*Z;
            maxIt = IterPerRound(colj,rowi);
            idext = N-size(idexNew,1)+1:N;
           % X_k(:,idext) = X_k(:,idext) - Yflag(:,idext).*(D*(S(idext,:))');
            X_k(:,idext) = X_k(:,idext) - Yflag(:,idext).*(D*(S(idext,:).*Z(idext,:))');
            %X_k(:,idext) = X_k(:,idext) - Yflag(:,idext).*(D*(S(idext,:))');
            if IsSparseCalculation
                X_k = sparsify(X_k);
                Yflag = sparsify(Yflag);
            end
            
            for iter=1:maxIt
                tic
                %Sample D, Z, and S 
%                 if size(IMin,3)==1
%                     Pi(1) = 1;
%                 end
                [X_k, D, Z, S] = SampleDZS_MissingData(X_k, D, Z, S, Pi, alpha, phi, Yflag, true, true, true,UpdateOption);
                
                %Sample Pi
                Pi = SamplePi(Z,a0,b0);  
                %Sample alpha
                alpha = Samplealpha(S,e0,f0,Z,alpha);
                %Sample phi
                phi = Samplephi(X_k,c0,d0,Yflag);
                ittime=toc;
                NoiseVar(end+1) = sqrt(1/phi)*255;
                
                
                if ReduceDictSize && colj>2
                    sumZ = sum(Z,1)';
                    if min(sumZ)==0
                        Pidex = sumZ==0;
                        D(:,Pidex)=[];
                        K = size(D,2);
                        S(:,Pidex)=[];
                        Z(:,Pidex)=[];
                        Pi(:,Pidex)=[];
                    end
                end
                
                
                if DispPSNR==1 || (rowi==PatchSize&&colj==PatchSize)
                    if rowi==PatchSize
                        %Iout    =   DenoiseOutput(D*(S.*Z)',sizeIMin,PatchSize,idex,MuX);
                        Iout    =   DenoiseOutput_LowMemoryReq(D,S,sizeIMin,PatchSize,idex);                        
                        PSNR(end+1) = -10*log10((mean((Iout(:)-IMin0(:)).^2)));
                        if rowi==PatchSize && mod(iter,10)==1
                            disp(['round:',num2str([colj,rowi]),'    iter:', num2str(iter), '    time: ', num2str(ittime), '    ave_Z: ', num2str(full(mean(sum(Z,2)))),'    M:', num2str(nnz(mean(Z,1)>1/1000)),'    PSNR:',num2str(PSNR(end)),'   NoiseVar:',num2str(NoiseVar(end)) ])
                            %save([IMname,'_Inpainting_',num2str(colj),'_',num2str(rowi),'_',num2str(dataratio),'_',num2str(sigma)], 'Iout', 'SampleMatrix','D','PSNR','Pi','IMin','IMin0','phi','alpha','b0','NoiseVar');
                        end
                    end
                end
            end
        end
    end
    
else
    
    %batch mode
    [idexi,idexj] = ind2sub(sizeIMin(1:2)-PatchSize+1,1:(sizeIMin(1)-PatchSize+1)*(sizeIMin(2)-PatchSize+1));
    idex = [idexi',idexj'];
    clear idexi idexj
    X_k = im2col(IMin,[PatchSize,PatchSize],'sliding');
    Yflag = logical(im2col(SampleMatrix,[PatchSize,PatchSize],'sliding'));
    %Sparsity Priors
    [P,N] = size(X_k);
    if strcmp(InitOption,'SVD')==1
        a0=1;
        b0=N/8;
    else
        a0=1;
        b0=1;
    end    
    [D,S,Z,phi,alpha,Pi] = InitMatrix_MissingData(X_k,K,Yflag,InitOption,IsSeparateAlpha,IMin);        
    Pi = Pi-Pi+0.001;
    X_k = X_k - Yflag.*(D*S');
    if IsSparseCalculation
        X_k = sparsify(X_k);
        Yflag = sparsify(Yflag);
    end
    maxIt = IterPerRound(end,end);
    
    for iter=1:maxIt
        tic
        %Sample D, Z, and S
        [X_k, D, Z, S] = SampleDZS_MissingData(X_k, D, Z, S, Pi, alpha, phi, Yflag, true, true, true,UpdateOption);
        %Sample Pi
        Pi = SamplePi(Z,a0,b0);
        %Sample alpha
        alpha = Samplealpha(S,e0,f0,Z,alpha);
        %Sample phi
        phi = Samplephi(X_k,c0,d0,Yflag);
        ittime=toc;
        NoiseVar(end+1) = sqrt(1/phi)*255;
        
        
        if ReduceDictSize && iter>20
            sumZ = sum(Z,1)';
            if min(sumZ)==0
                Pidex = sumZ==0;
                D(:,Pidex)=[];
                K = size(D,2);
                S(:,Pidex)=[];
                Z(:,Pidex)=[];
                Pi(:,Pidex)=[];
            end
        end
        
        
        if iter>=20
            %Iout    =   DenoiseOutput(D*(S.*Z)',sizeIMin,PatchSize,idex,MuX);
            Iout    =   DenoiseOutput_LowMemoryReq(D,S,sizeIMin,PatchSize,idex);            
            PSNR(end+1) = -10*log10((mean((Iout(:)-IMin0(:)).^2)));
            if mod(iter,10)==1
                disp(['iter:', num2str(iter), '    time: ', num2str(ittime), '    ave_Z: ', num2str(full(mean(sum(Z,2)))),'    M:', num2str(nnz(mean(Z,1)>1/1000)), '    PSNR:',num2str(PSNR(end)),'   NoiseVar:',num2str(NoiseVar(end)) ])
                %save([IMname,'_Inpainting_',num2str(iter),'_',num2str(dataratio),'_',num2str(sigma)], 'Iout', 'SampleMatrix','D','PSNR','Pi','IMin','IMin0','phi','alpha','b0','NoiseVar');
            end
        end
    end
end
save([IMname,'_Inpainting_',num2str(dataratio),'_',num2str(sigma)],'D','S','Z','SampleMatrix','phi','alpha','PSNR','IMin','IMin0','idex','Iout','Pi','b0','NoiseVar','Yflag');
end