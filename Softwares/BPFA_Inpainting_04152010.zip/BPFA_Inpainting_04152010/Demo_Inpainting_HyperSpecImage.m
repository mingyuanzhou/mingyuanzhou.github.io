% Hyperspectral image inpainting running file for the paper:
% M. Zhou, H. Chen, J. Paisley, L. Ren, L. Li, Z. Xing, D. Dunson,   
% G. Sapiro and L. Carin, Nonparametric Bayesian Dictionary Learning for
% Analysis of Noisy and Incomplete Images, submitted.  
% Coded by: Mingyuan Zhou, ECE, Duke University, mz1@ee.duke.edu
% Version 0: 06/14/2009
% Version 1: 09/21/2009
% Version 2: 10/26/2009
% Version 3: 10/28/2009
% Last Updated: 03/31/2010

clear all
load R1.mat 
PatchSize = 2; %block size
K = 256;  %dictionary size   
IMname = 'UrbanR1';
IMin0 = double(R1);
for layer=1:size(IMin0,3)
    IMin0(:,:,layer) = IMin0(:,:,layer)/max(max(IMin0(:,:,layer)));
end
SampleMatrix = false(size(IMin0));
rand('state',0);
SampleIndex = randperm(numel(SampleMatrix));
DataRatio = 0.02; %0.3, 0.5
SampleMatrix(SampleIndex(1: fix(DataRatio*numel(SampleMatrix)))) = true; 
IMin = IMin0.*SampleMatrix;

IMname = [IMname,'_',num2str(fix(DataRatio*100)),'_',num2str(PatchSize)];

IterPerRound = ones(PatchSize,PatchSize); %Maximum iteration in each round
IterPerRound(end,end) = 100;

DispPSNR = false; %Calculate and display the PSNR or not
ReduceDictSize = false; %Reduce the ditionary size during training if it is TRUE
SparseCalculationT = 0.6; %A threshold used to decide whether sparse 
%calculations should be used based on the percentage of the observed data, 
%it would only affect the speed and has no effect on the performance.

InitOption = 'Rand';
UpdateOption = 'DkZkSk';
LearningMode = 'online';
IsSeparateAlpha = false;
sigma = [];
[Iout,D,S,Z,idex,Pi,NoiseVar,alpha,phi,PSNR] = BPFA_Inpainting(IMin, SampleMatrix, PatchSize, K, DispPSNR, IsSeparateAlpha, InitOption, UpdateOption, LearningMode, IterPerRound, ReduceDictSize,IMin0,sigma,IMname,SparseCalculationT);
[temp, Pidex] = sort(Pi,'descend');
Dsort = D(:,Pidex);
I = DispDictionary(Dsort);
title('The dictionary trained on the corrupted image');

PSNRIn = -10*log10(mean((IMin(:)-IMin0(:)).^2));
PSNROut = -10*log10(mean((min(max(Iout(:),0),1)-IMin0(:)).^2));

for layer= [1,100]
    figure;
    subplot(1,3,1); imshow(IMin(:,:,layer)); title(['Corrupted image, ',num2str(PSNRIn),'dB']);
    ylabel(['spectral band\_',num2str(layer)])
    subplot(1,3,3); imshow(IMin0(:,:,layer)); title('Original image');
    subplot(1,3,2); imshow(Iout(:,:,layer)); title(['Restored image,',num2str(PSNROut),'dB']);    
end