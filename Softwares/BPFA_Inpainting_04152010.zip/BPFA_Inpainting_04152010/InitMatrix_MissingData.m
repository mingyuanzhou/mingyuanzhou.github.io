function [D,S,Z,phi,alpha,Pi] = InitMatrix_MissingData(X_k,K,Yflag,InitOption,IsSeparateAlpha,IMin)
%Initialization
%Version 1: 09/12/2009
%Version 2: 10/21/2009
%Version 3: 10/26/2009
%Version 4: 10/28/2009
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu

[P,N]=size(X_k);
if nargin<5
    IsSeparateAlpha = false;
end
phi = 1/((25/255)^2);
if IsSeparateAlpha == false
    alpha = 1;
else
    alpha = ones(1,K);
end

dataratio = nnz(Yflag)/numel(Yflag);

MuX =  sum(X_k.*Yflag,2)./(sum(Yflag,2)+realmin);
X_k = X_k.*Yflag + repmat(MuX,1,N).*(~Yflag);
if strcmp(InitOption,'SVD')==1 
    [U_1,S_1,V_1] = svd(full(X_k),'econ');
    if P<=K
        D = zeros(P,K);
        D(:,1:P) = U_1*S_1;
        S = zeros(N,K);
        S(:,1:P) = V_1;
    else
        D =  U_1*S_1;
        D = D(1:P,1:K);
        S = V_1;
        S = S(1:N,1:K);
    end
    %Z = true(N,K);
    if size(IMin,3)==1
        Z = rand(N,K) < dataratio;
        Pi = dataratio*ones(1,K);
    else
        Z = true(N,K);
        Pi = 0.5*ones(1,K);
    end
else
    D = randn(P,K)/sqrt(P);
    S = randn(N,K);
    Z = logical(sparse(N,K));
    Pi = 0.01*ones(1,K);    
    if nnz(~Yflag)==0 
        D(:,1) = MuX*100;
        S(:,1)=1/100;
        Z(:,1)= true;
        %Pi(1) = 1;
    end
    
%     if size(IMin,3)>=1
%         D(:,1) = MuX*100;
%         S(:,1)=1;
%         Z(:,1)= true;
%         %Pi(1) = 1;
%     end
    
end
%S = S.*Z;
end




