Matlab code for the paper:
M. Zhou, H. Chen, J. Paisley, L. Ren, L. Li, Z. Xing, D. Dunson,   
G. Sapiro and L. Carin, Nonparametric Bayesian Dictionary Learning for
Analysis of Noisy and Incomplete Images, submitted.  
Coded by: Mingyuan Zhou, ECE, Duke University, mz1@ee.duke.edu, mingyuan.zhou@duke.edu


File list:

Demo files:
Demo_Inpainting_GRAY.m: Running file for BPFA gray-scale image inpainting.
Demo_Inpainting_RGB.m: Running file for BPFA RGB image inpainting.
Demo_Inpainting_HyperSpecImage.m: Running file for BPFA Hyperspectral image inpainting.
Demo_Denoise_Inpainting_GRAY.m: Running file for gray-scale image simultaneous denoising & inpainting 

Main programs:
BPFA_Inpainting.m: The BPFA image inpainting program.

Subprograms for Gibbs sampling:
SampleDZS_Missingdata.m: Sampling the dictionary D, the binary indicating matrix Z, and the pseudo weight matrix S. Used for missing data case.
SamplePi.m: Sampling Pi.
Samplephi.m: Sampling the noise precision phi.
Samplealpha: Sampling alpha, the precision of si.

Subprograms for the updates in sequential learning
idexUpdate.m: Update the index of the training data in the input data matrix X.
Update_Input_Missingdata.m: Update the training data set in sequential learning. Used for missing data case.
SZUpdate.m: Update the pseudo weight matrix S and binary indicating matrix Z in sequential learning.

Other subprograms:
sparsity.m: Squeeze out zero components in the sparse matrix.
DispDictionary.m: Display the dictionary elements as a image
DenoiseOutput_LowMemoryReq.m: Reconstruct the image
InitMatrix_Denoise.m: Initialization for gray-scale image denoising
sparse_mult.m: Use sparse multiplication to eliminate unnecessary computation

house.png: the original house image. 
barbara256.png: the barbara256 image.
Other gray scale test images can be downloaded from http://www.cs.tut.fi/~foi/GCF-BM3D/

castle.png: the original castle image. Other RGB test images can be found in The Berkeley Segmentation Dataset and Benchmark.

R1.mat: a 150*150*210 hyperspectral urban image.

Papers and test results related to the code can be found at http://people.ee.duke.edu/~mz1/