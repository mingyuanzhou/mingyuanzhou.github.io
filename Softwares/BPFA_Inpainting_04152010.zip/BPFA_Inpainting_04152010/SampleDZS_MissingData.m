function [X_k, D, Z, S] = SampleDZS_MissingData(X_k, D, Z, S, Pi, alpha, phi, Yflag, Dsample, Zsample, Ssample,UpdateOption)
%Sample the Dictionary D, the Sparsity Pattern Z, and the Pesudo Weights S
%when there are missing data
%Version 1: 10/26/2009
%Version 2: 10/28/2009
%Updated in 03/09/2010
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu
if nargin<9
    Dsample = true;
end
if nargin<10
    Zsample = true;
end
if nargin<11
    Ssample = true;
end
if nargin<12
    UpdateOption = 'DkSkZk';
end

if issparse(Yflag)
    sparseCalculation = true;
else
    sparseCalculation = false;
end

[P,N] = size(X_k);
K = size(D,2);
if length(alpha)==1
    alpha = repmat(alpha,1,K);
end

%Z = full(Z);

if strcmp(UpdateOption, 'DkZkSk')==1
    for k=1:K
        nnzk = nnz(Z(:,k));
        if nnzk>0
            if sparseCalculation
                X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
            else
                X_k(:,Z(:,k)) = X_k(:,Z(:,k))+ Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
            end
        end
        
        if Dsample
            %Sample D
            sig_Dk = 1./(phi*Yflag(:,Z(:,k))*(S(Z(:,k),k).^2)+P);
            mu_D = phi*sig_Dk.*(X_k(:,Z(:,k))*S(Z(:,k),k));
            D(:,k) = mu_D + randn(P,1).*sqrt(sig_Dk);
        end
        
        if Zsample || Ssample
            DTD = (D(:,k).^2)'*Yflag;
        end
        
        if Zsample
            %Sample Z
            Sk = full(S(:,k));
            Sk(~Z(:,k)) = randn(N-nnz(Z(:,k)),1)*sqrt(1/alpha(k));
            temp =  - 0.5*phi*( (Sk.^2 ).*(DTD)' - 2*Sk.*(X_k'*D(:,k)) );
            temp = exp(temp).*Pi(:,k);
            Z(:,k) = sparse( rand(N,1) > ((1-Pi(:,k))./(temp+1-Pi(:,k))) );
            %             temp = temp + log(Pi(:,k)+realmin) - log(1-Pi(:,k)+realmin);
            %             Z(:,k) = ( rand(N,1) > (1./(exp(temp)+1)) );
        end
        
        nnzk = nnz(Z(:,k));
        
        if Ssample
            if nnzk>0
                %Sample S
                sigS1 = 1./(alpha(k) + phi*DTD(Z(:,k))');
                %S(Z(:,k),k) = randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k));
                %S(~Z(:,k),k) = randn(N-nnzk,1)*sqrt(1/alpha(k));
                S(:,k) = sparse(find(Z(:,k)),1,randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k)), N,1);
            else
                S(:,k) = 0;
            end
        end
        % X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
        
        if nnzk>0
            if sparseCalculation
                X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
            else
                X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
            end
        end
    end
elseif strcmp(UpdateOption, 'DZS')==1
    %Sample D
    if Dsample
        for k=1:K
            nnzk = nnz(Z(:,k));
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))+ Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
            sig_Dk = 1./(phi*Yflag(:,Z(:,k))*(S(Z(:,k),k).^2)+P);
            mu_D = phi*sig_Dk.*(X_k(:,Z(:,k))*S(Z(:,k),k));
            D(:,k) = mu_D + randn(P,1).*sqrt(sig_Dk);
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
        end
        %clear sig_Dk mu_D
    end
    
    %Sample Z
    if Zsample
        for k=1:K
            nnzk = nnz(Z(:,k));
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))+ Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
            DTD = (D(:,k).^2)'*Yflag;
            Sk = full(S(:,k));
            Sk(~Z(:,k)) = randn(N-nnz(Z(:,k)),1)*sqrt(1/alpha(k));
            temp =  - 0.5*phi*( (Sk.^2 ).*(DTD)' - 2*Sk.*(X_k'*D(:,k)) );
            temp = exp(temp).*Pi(:,k);
            Z(:,k) = sparse( rand(N,1) > ((1-Pi(:,k))./(temp+1-Pi(:,k))) );
            nnzk = nnz(Z(:,k));
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
        end
        %clear Sk temp
    end
    Z = sparsify(Z);
    
    %Sample S
    if Ssample
        for k=1:K
            nnzk = nnz(Z(:,k));
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))+ Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
            DTD1 = (D(:,k).^2)'*Yflag(:,Z(:,k));
            sigS1 = 1./(alpha(k) + phi*DTD1');
            %S(Z(:,k),k) = randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k));
            %S(~Z(:,k),k) = 0;
            %S(~Z(:,k),k) = randn(N-nnzk,1)*sqrt(1/alpha);
            S(:,k) = sparse(find(Z(:,k)),1,randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k)), N,1);
            if nnzk>0
                if sparseCalculation
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse_mult(Yflag(:,Z(:,k)),D(:,k),S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
        end
        %clear sigS1
    end
end

Z = sparsify(Z);
S = sparsify(S);