% Gray-scale image inpainting running file for the paper:
% M. Zhou, H. Chen, J. Paisley, L. Ren, L. Li, Z. Xing, D. Dunson,   
% G. Sapiro and L. Carin, Nonparametric Bayesian Dictionary Learning for
% Analysis of Noisy and Incomplete Images, submitted.  
% Coded by: Mingyuan Zhou, ECE, Duke University, mz1@ee.duke.edu,
% mingyuan.zhou@duke.edu
% Version 0: 06/14/2009
% Version 1: 09/21/2009
% Version 2: 10/26/2009
% Version 3: 10/28/2009
% Last Updated: 03/31/2010

clear all

sigma = [];  % noise stand deviation
DataRatio = 0.2; %0.05, 0.1, 0.2, 0.3, 0.5, 0.8

PatchSize = 8; %block size

IMname = 'house'; %'house', 'peppers256','Lena512','barbara','boat','fingerprint','Cameraman256','couple','hill','man','montage'
IMin0 = imread([IMname,'.png']);
%IMin0 = IMin0(1:256,257:end);
IMin0 = im2double(IMin0); %IMin0 as an input is only used to calculate the 
%PSNR and would not affect the Inpainting reults 
SampleMatrix = false(size(IMin0));
rand('state',0);
SampleIndex = randperm(numel(IMin0));
SampleMatrix(SampleIndex(1: fix(DataRatio*numel(SampleMatrix)))) = true; %binary matrix indicating which pixel values are observed

IMin = IMin0.*SampleMatrix;

IMname = [IMname,'_',num2str(fix(DataRatio*100))];
PSNRIn = -10*log10(mean((IMin(:)-IMin0(:)).^2));

IterPerRound = ones(PatchSize,PatchSize); %Maximum iteration in each round
IterPerRound(end,end) = 150;

DispPSNR = true; %Calculate and display the PSNR or not;
ReduceDictSize = false; %Reduce the ditionary size during training if it is TRUE, can be used to reduce computational complexity 
IsSeparateAlpha = false; %use a separate precision for each factor score vector if it is TRUE. 


if size(IMin,1)*size(IMin,2)<=300*300
    K = 256;  %dictionary size
else
    K = 512;
end


InitOption = 'SVD';
if DataRatio == 1
    UpdateOption = 'DkZkSk';
else
    UpdateOption = 'DZS';
end


% % another setting:
% InitOption = 'Rand'; %Initialization with 'SVD' or 'Rand'
% UpdateOption = 'DkZkSk'; %'DkSkZk' or 'DZS', Update options, the computation requirments are 'DkZkSk'<'DZS'


LearningMode = 'online'; %'online' or 'batch'
SparseCalculationT = 0.6; %A threshold used to decide whether sparse 
%calculations should be used based on the percentage of the observed data, 
%it would only affect the speed and has no effect on the performance.

[Iout,D,S,Z,idex,Pi,NoiseVar,alpha,phi,PSNR] = BPFA_Inpainting(IMin, SampleMatrix, PatchSize, K, DispPSNR, IsSeparateAlpha, InitOption, UpdateOption, LearningMode, IterPerRound, ReduceDictSize,IMin0,sigma,IMname,SparseCalculationT);
PSNROut = PSNR(end);
figure;
subplot(1,3,1); imshow(IMin); title(['Corrupted image, ',num2str(PSNRIn),'dB']);
subplot(1,3,2); imshow(IMin0); title('Original image');
subplot(1,3,3); imshow(Iout); title(['Restored image, ',num2str(PSNROut),'dB']);
print(gcf,'-dpng',[IMname '_results.png'])
imwrite(Iout, [IMname '.png']);
figure;
[temp, Pidex] = sort(full(sum(Z,1)),'descend');
Dsort = D(:,Pidex);
I = DispDictionary(Dsort);
imwrite(I, [IMname '_dict.png']);
title('The dictionary trained on the corrupted image');