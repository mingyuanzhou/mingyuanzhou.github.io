function [Yflag,X_k] = Update_Input_MissingData(Yflag,X_k,IMin,SampleMatrix,idexNew,PatchSize,IsSparseCalculation)
%Version 1: 11/02/2009
%Updated in 03/09/2010
%Written by Mingyuan Zhou, Duke ECE, mz1@ee.duke.edu
if nargin<7
    IsSparseCalculation = true;
end

N = size(idexNew,1);
P = size(IMin,3)*PatchSize^2;
YflagNew = false(P,N);
XNew = zeros(P,N);
for i=1:N
    Pos1 = idexNew(i,1)+(0:PatchSize-1);
    Pos2 = idexNew(i,2)+(0:PatchSize-1);    
    YflagNew(:,i) = reshape(logical(SampleMatrix(Pos1,Pos2,:)),P,1);
    XNew(:,i) = reshape(IMin(Pos1,Pos2,:),P,1);
end

Yflag = [Yflag,YflagNew];
XNew = XNew.*YflagNew;
X_k = [X_k,XNew];
if IsSparseCalculation
    Yflag = sparsify(Yflag);
    X_k = sparsify(X_k);
end
end
