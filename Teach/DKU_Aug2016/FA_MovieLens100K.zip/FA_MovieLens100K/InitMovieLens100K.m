function [Scale,IMin,IMin0,SampleMatrix, SampleMatrixTest] = InitMovieLens100K(Train,Test)
fid = fopen(Train);
C = textscan(fid,'%d %d %d %d','Delimiter',' ','MultipleDelimsAsOne',1);
fclose(fid);
IMin = sparse(double(C{1}),double(C{2}),double(C{3}));

fid = fopen(Test);
D = textscan(fid,'%d %d %d %d','Delimiter',' ','MultipleDelimsAsOne',1);
fclose(fid);
IMin0 = sparse([double(C{1});double(D{1})],[double(C{2});double(D{2})],[double(C{3});double(D{3})]);

SampleMatrixTest = true(size(IMin0));
SampleMatrixTest(IMin0==0 | IMin~=0) = false;
SampleMatrixTest = sparse(SampleMatrixTest);

SampleMatrix = false(size(IMin));
SampleMatrix(IMin~=0) = true;
SampleMatrix = sparse(SampleMatrix);

IMin = IMin.*SampleMatrix;
Scale = 5;