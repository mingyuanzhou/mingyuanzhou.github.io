function [RMSE,MAE_T] = rmse_mae(IMin0,Iout,SampleMatrixTest,Scale,Increment)
if nargin<4
    Scale = 5;
end
if nargin<5
    Increment = 1;
end
[P,N]=size(IMin0);
RMSE = sqrt(sum(nonzeros(Iout.*SampleMatrixTest - IMin0.*SampleMatrixTest).^2)/nnz(SampleMatrixTest));
[ii,jj,ss]=find(Iout.*SampleMatrixTest);
Iout1 = sparse(ii,jj, min(max(round(ss/Increment)*Increment,1),Scale),P,N);
MAE_T = sum(abs(nonzeros(Iout1-IMin0.*SampleMatrixTest)))/nnz(SampleMatrixTest);