%Matlab code for Duke-Tshinghua Machine Learning Summber School, Duke
%Kunshan University, Kunshan, China, August 2, 2016
%Lecture: Mingyuan Zhou
%http://mingyuanzhou.github.io/

%Bayesian factor analysis for missing data inputation
%MovieLens 100K dataset
%943 Users, 1682 Movies
%80,000 observed ratings for training
%20,000 observed ratings for testing
%Choose TypeBases = 'Movie' to factorize the User-Movie Matrix
%Choose TypeBases = 'User' to factorize the Movie-User Matrix


clear all
hold on
Bases = {'Movie','User'};
count = 0;
sparseCalculation = true;

State =1 %  1:5
Base = 1 % 1:2
%Kall = [2,5,10,20,35,50,65,80,100,200,150];
Kall = 160 %[5,10,20,40,80,160];

Results = zeros(length(Kall),1);
SinglePrecision = false
% if SinglePrecision = true, then s_{i1},..,s_{iK} share the same precision parameter
% if SinglePrecision = false, then s_{ik}~N(0,\alpha_k^{-1})

for i=1:length(Kall)
    K = Kall(i)
    %         for State = 3
    %     for Form=1
    State
    
    TypBases = Bases{Base}
    
    %rng(State,'twister');  Uncomment this line to control the random seed.
    
    [Scale,IMin,IMin0,SampleMatrix,SampleMatrixTest] = InitMovieLens100K('u1.base','u1.test');
    %IMin0 is the observed user-movie rating matrix, with 943 users
    %and 1682 movies
    %SampleMatrix is the corresponding mask
    %IMin is the training user-movie rating matrix
    %SampleMatrixTest is the mask for held out ratings
    
    if strcmp(TypBases,'Movie')==false
        %Rotate the user-movie matrix to be a movie-user matrix
        IMin = IMin';
        IMin0 = IMin0';
        SampleMatrix = SampleMatrix';
        SampleMatrixTest = SampleMatrixTest';
    end
    
    
    Burnin = 1000;
    Collection = 500;
    maxIt = Burnin+Collection;
    
    IMin = IMin0.*SampleMatrix; %Observed user-movie rating matrix
    
    [P,N] = size(IMin);
    Iout = sparse(P,N);
    D = randn(P,K)/sqrt(P);
    S = sparse(N,K);
    Z = sparse(false(N,K));
    
    Pi = 0.01*ones(K,1);
    a0=1/K;
    b0=1;
    
    
    phi = 1/((50/255)^2);
    alpha_s = ones(K,1);
    
    Yflag = sparse(SampleMatrix);
    YflagT = Yflag';
    
    c0=1e-6;
    d0=1e-6;
    e0=1e-6;
    f0=1e-6;
    
    
    NoiseVar=zeros(maxIt,1);
    Train.RMSE=zeros(maxIt,1);
    Test.RMSE=zeros(maxIt,1);
    Test.MAE_T=zeros(maxIt,1);
    ave.RMSE=zeros(maxIt,1);
    ave.MAE_T=zeros(maxIt,1);
    ave.Iout = sparse(P,N);
    ave.Sigma = sparse(P,N);
    ave.Count = 0;
    
    
    X_k = IMin/Scale - Yflag.*(D*S'); %Scale data to be between 0 and 1
    
    sumYflag = nnz(Yflag);
    DispRMSE = true;
    X_k = sparse(X_k);
    
    for iter=1:Burnin+Collection;
        tic
        
        for k=1:K
            nnzk = nnz(Z(:,k));
            if nnzk>0
                if sparseCalculation
                    %X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse(spdiags(D(:,k),0,speye(P))*Yflag(:,Z(:,k)))*spdiags(S(Z(:,k),k),0,speye(nnzk));
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) + sparse(1:P,1:P, D(:,k))*Yflag(:,Z(:,k))*sparse(1:nnzk,1:nnzk,S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))+ Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
            
            %Sample D
            sig_Dk = 1./(phi*Yflag(:,Z(:,k))*(S(Z(:,k),k).^2) + P);
            mu_D = phi*sig_Dk.*(X_k(:,Z(:,k))*S(Z(:,k),k));
            D(:,k) = mu_D + randn(P,1).*sqrt(sig_Dk);
            
            
            
            DTD = (D(:,k).^2)'*Yflag;
            
            
            %Sample Z
            Sk = full(S(:,k));
            Sk(~Z(:,k)) = randn(N-nnz(Z(:,k)),1)*sqrt(1/alpha_s(k));
            temp =  - 0.5*phi*...
                ( (Sk.^2 ).*(DTD)' - 2*Sk.*(X_k'*D(:,k)) );
            temp = exp(temp)*Pi(k);
            Z(:,k) = rand(N,1) > ((1-Pi(k))./(temp+1-Pi(k)));
            
            
            nnzk = nnz(Z(:,k));
            
            
            if nnzk>0
                %Sample S
                sigS1 = 1./(alpha_s(k) + phi*DTD(Z(:,k))');
                %S(Z(:,k),k) = randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k));
                %S(~Z(:,k),k) = 0;
                %S(~Z(:,k),k) = randn(N-nnzk,1)*sqrt(1/alpha_s(k));
                if sparseCalculation
                    S(:,k) = sparse(find(Z(:,k)),1,randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k)), N,1);
                else
                    S(:,k) = 0;
                    S(Z(:,k),k) = randn(nnzk,1).*sqrt(sigS1)+ sigS1.*(phi*X_k(:,Z(:,k))'*D(:,k));
                end
            else
                S(:,k) = 0;
            end
            
            % X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
            
            if nnzk>0
                if sparseCalculation
                    %X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse(spdiags(D(:,k),0,speye(P))*Yflag(:,Z(:,k)))*spdiags(S(Z(:,k),k),0,speye(nnzk));
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k)) - sparse(1:P,1:P, D(:,k))*Yflag(:,Z(:,k))*sparse(1:nnzk,1:nnzk,S(Z(:,k),k));
                else
                    X_k(:,Z(:,k)) = X_k(:,Z(:,k))- Yflag(:,Z(:,k)).*(D(:,k)*S(Z(:,k),k)');
                end
            end
        end
        
        if SinglePrecision == false
            %ei = e0+0.5*N; fi = f0 + 0.5*sum(S.^2,1)' + 0.5*(N-sum(Z,1))'.*(1./alpha_s); alpha_s = gamrnd(ei,1./fi);
            ei = e0+0.5*N; fi = f0 + 0.5*sum(S.^2,1)' + 0.5*chi2rnd((N-sum(Z,1))').*(1./alpha_s); alpha_s = gamrnd(ei,1./fi);
            %note that sum of squared standard normals are chi2 distributed
        else
            %ei = e0+0.5*numel(Z); fi = f0 + 0.5*sum(sum(S.^2)) + 0.5*(numel(Z)-nnz(Z))*(1./alpha_s(1)); alpha_s = repmat(gamrnd(ei,1./fi),K,1);
            ei = e0+0.5*numel(Z); fi = f0 + 0.5*sum(sum(S.^2)) + 0.5*chi2rnd(numel(Z)-nnz(Z))*(1./alpha_s(1)); alpha_s = repmat(gamrnd(ei,1./fi),K,1);
        end
        
        sumZ = full(sum(Z,1)');
        Pi = betarnd(sumZ+a0, b0+N-sumZ);
        
        ci = c0 + 0.5*sumYflag; di = d0 + 0.5*sum(nonzeros(X_k).^2); phi = gamrnd(ci,1./di);
        
        NoiseVar(iter) = sqrt(1/phi);
        
        Iout = Scale*sparse_mult(SampleMatrixTest,D,S);
        Iout = max(min(Iout,max(IMin(:))),min(IMin(:)));
        
        
        if mod(iter,100)==0
            [Test.RMSE(iter),Test.MAE_T(iter)] = rmse_mae(IMin0,Iout,SampleMatrixTest,Scale);
        end
        
        if iter>Burnin
            ave.Iout = ave.Iout + Iout;
            ave.Sigma = ave.Sigma + Iout.^2;
            ave.Count = ave.Count+1;
            [ave.RMSE(iter),ave.MAE_T(iter)] = rmse_mae(IMin0,ave.Iout/ave.Count,SampleMatrixTest,Scale);
        end
        
        ittime=toc;
        if mod(iter,100)==0
            disp(['iter:', num2str(iter), ' time per iter: ', num2str(ittime),' Output: ', num2str([Train.RMSE(iter),Test.RMSE(iter),Test.MAE_T(iter),ave.RMSE(iter),ave.MAE_T(iter)]),' NoiseVar:',num2str(NoiseVar(iter)) ])
        end
    end
    Results(i)=ave.RMSE(end);
    figure(100);plot(Kall(1:i),Results(1:i),'-->')
    drawnow
end


